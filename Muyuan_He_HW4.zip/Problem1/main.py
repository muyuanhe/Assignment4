import numpy as np #mainly for matrix operation
import scipy.integrate as ode
import matplotlib.pyplot as plt
from numpy import linalg as LA # eigen value/vectors from LA
import math as m
# TOOLS
#A = np.matrix('1 2; 3 4')
#B = np.linalg.inv(A)
#zeors_array = np.zeros( (2, 3) )

### Problem 1
# def funct1_drdt(t, r): #a>0 case ## adaptive time step
#     a = 1
#     return r*(a-r**2)
# def funct2_drdt(t, r): #a<0 case
#     a = -1
#     return r*(a-r**2)
# #y0 = np.array().; for i in range(100)
# array = np.arange(-1, -100, -1) # dtheta/dt = -1
# array1 = ode.RK45(funct1_drdt, 0, array, 100)

###### Here, change the sign of a
a = 0.5
#a = -0.5
######
def derivative1(r, t): # a>0 case
    #a = 1
    drdt = a*r - r**3
    return drdt

def RK4(x_val, time, delta_t):
    F1 = derivative1(x_val, time)
    F2 = derivative1(x_val+0.5*delta_t*F1, time+0.5*delta_t)
    F3 = derivative1(x_val+0.5*delta_t*F2, time+0.5*delta_t)
    F4 = derivative1(x_val+dt*F3, time+delta_t)
    result = x_val+delta_t*(F1+2*F2+2*F3+F4)/6
    return result
# Now use adaptive Runge_Kutta method
# setup variables
dt = 0.1 #current tau
tau_old = 0.1
tau_est = 0.1
tau_new = 0.1
r = 1
t = 0
delta_i = 0.001
s1 = 0.8
s2 = 1.2
x = np.zeros(1000)
y = np.zeros(1000)
theta = 0
for i in np.arange(1000):
    ### following steps to adjust time_step
    t = t+dt # originally t is 0, each time adds dt
    x_big = RK4(r, t, dt)
    #print("x_big", x_big)
    x_small = RK4(r, t, dt/2)
    #print("x_small_half", x_small)
    x_small = RK4(x_small, t, dt/2)
    #print("x_small", x_small)

    delta_c = abs(x_big - x_small)
    tau_est = dt*(delta_i/delta_c)**(1/5)
    if s1*tau_est > s2*tau_old:
        tau_new = s2*tau_old
    elif s1*tau_est < s2*tau_old:
        tau_new = tau_old/s2
    else:
        tau_new = s1*tau_est
    tau_old = dt #replace old with current
    dt = tau_new #replace current with new

    ### following steps to actually use RK4
    r = RK4(r, t, dt)
    theta -= dt
    x[i] = r*m.cos(theta)
    y[i] = r*m.sin(theta)
    #print("x: ", x[i], "\n")
    #print("y: ", y[i], "\n")
# Make plot below
plt.plot(x, y)
plt.show()





### Problem 2
# part c
M = np.zeros((50, 50))

for index, value in np.ndenumerate(M):
    #print(index[0], index[1], value)
    if abs(index[0]-index[1])<3:
        M[index[0]][index[1]] = 1

#print(M)
eigen = LA.eig(M) # eigen[0] are eigen values, eigen[1] are eigen vectors
#print(eigen)
print("λmax = ", max(eigen[0]))
mod_list = []
for i in eigen[1]:
    square_sum = 0
    for j in i:
        square_sum += j**2
    mod_list.append(square_sum)
mod_max = max(mod_list)
#print(mod_max)
mod_max_iter = mod_list.index(mod_max)
#print(mod_max_iter) #18
print("vmax = ", eigen[1][mod_max_iter] )
#print("vmax = ", max(eigen[1]))

# part d
b_k = np.ones(50)
b_k_minus = np.ones(50)
kmax = 0
for k in np.arange(1000):
    b_k =M.dot(b_k_minus/LA.norm(b_k_minus))
    kmax += 1
    if LA.norm(b_k - b_k_minus) < 1E-6*LA.norm(b_k):
        break
    b_k_minus = b_k

print("bk_max is: ", b_k)
print("kmax: ", kmax)

for l in range(50):
    print("proportion: ", b_k[l]/eigen[1][mod_max_iter])

sol = M.dot(b_k) -max(eigen[0])*(b_k)
print(sol)
#LA.norm(a)

